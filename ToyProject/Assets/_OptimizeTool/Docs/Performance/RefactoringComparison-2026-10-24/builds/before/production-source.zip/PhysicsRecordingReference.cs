using System;
using UnityEngine;

namespace Common.OptimizeTool
{
    /// <summary>Unreduced physics observations, independent of the exported animation curves.</summary>
    public sealed class PhysicsRecordingReference : ScriptableObject
    {
        [Serializable]
        private struct Pose
        {
            public Vector3 Position;
            public Quaternion Rotation;
        }

        [SerializeField] private AnimationClip _clip;
        [SerializeField] private string[] _paths;
        [SerializeField] private float[] _times;
        // Frame-major layout: every observation has a pose for each transform path.
        [SerializeField] private Pose[] _poses;
        public AnimationClip Clip => _clip;
        public int TrackCount => _paths?.Length ?? 0;
        public int ObservationCount => _times?.Length ?? 0;
        public float Duration => ObservationCount == 0 ? 0f : _times[_times.Length - 1];
        public string Path(int track) => _paths[track];
        public float TimeAt(int observation) => _times[observation];

        public PhysicsPoseSample Sample(int track, float time)
        {
            if (track < 0 || track >= TrackCount || ObservationCount == 0)
                throw new ArgumentOutOfRangeException(nameof(track));
            int found = Array.BinarySearch(_times, time);
            int upper = found >= 0 ? found : Mathf.Clamp(~found, 0, ObservationCount - 1);
            int lower = found >= 0 ? found : Mathf.Max(0, upper - 1);
            Pose a = _poses[lower * TrackCount + track];
            Pose b = _poses[upper * TrackCount + track];
            if (lower == upper) return new PhysicsPoseSample(time, a.Position, a.Rotation);
            return PhysicsPoseSample.Interpolate(
                new PhysicsPoseSample(_times[lower], a.Position, a.Rotation),
                new PhysicsPoseSample(_times[upper], b.Position, b.Rotation), time);
        }

        public static string AssetPathForClip(string clipPath) =>
            System.IO.Path.ChangeExtension(clipPath, ".reference.asset");

#if UNITY_EDITOR
        internal void Initialize(AnimationClip clip, PhysicsRecordedTake take)
        {
            _clip = clip;
            _paths = new string[take.Tracks.Count];
            var observations = take.Tracks[0].Observations;
            _times = new float[observations.Count];
            _poses = new Pose[_times.Length * _paths.Length];
            for (int frame = 0; frame < _times.Length; frame++)
            {
                _times[frame] = observations[frame].Time;
                for (int track = 0; track < _paths.Length; track++)
                {
                    _paths[track] = take.Tracks[track].Path;
                    PhysicsPoseSample sample = take.Tracks[track].Observations[frame];
                    _poses[frame * _paths.Length + track] = new Pose
                    { Position = sample.Position, Rotation = sample.Rotation };
                }
            }
        }
#endif
    }
}
