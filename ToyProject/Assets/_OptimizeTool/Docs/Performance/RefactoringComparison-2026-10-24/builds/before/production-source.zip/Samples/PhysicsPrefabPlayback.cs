using System;
using UnityEngine;

namespace Common.OptimizeTool.Samples
{
    /// <summary>Owns a validated playback instance and its manually sampled Legacy Animation.</summary>
    internal sealed class PhysicsPrefabPlayback
    {
        public GameObject Instance { get; private set; }
        private readonly Animation _animation;
        private readonly Transform[] _bodies;
        private AnimationState _state;
        public float Length => _animation.clip.length;
        public Transform Body(int index) => _bodies[index];

        private PhysicsPrefabPlayback(GameObject instance, Animation animation, Transform[] bodies)
        {
            Instance = instance;
            _animation = animation;
            _bodies = bodies;
        }

        public static PhysicsPrefabPlayback Create(GameObject prefab, Transform anchor, Rigidbody[] source)
        {
            GameObject instance = UnityEngine.Object.Instantiate(prefab, anchor, false);
            try
            {
                instance.name = "Recorded Prefab Playback";
                Animation animation = instance.GetComponent<Animation>();
                if (animation == null || animation.clip == null || !animation.clip.legacy
                    || instance.GetComponentsInChildren<Rigidbody>(true).Length != 0
                    || instance.GetComponentsInChildren<Collider>(true).Length != 0)
                    throw new InvalidOperationException("The saved recording must have a Legacy clip and no physics components.");
                animation.Stop();
                animation.clip.SampleAnimation(instance, 0f);
                var bodies = new Transform[source.Length];
                for (int i = 0; i < bodies.Length; i++)
                {
                    // The sample's rigidbodies are direct children with unique names.
                    bodies[i] = instance.transform.Find(source[i].name);
                    if (bodies[i] == null)
                        throw new InvalidOperationException("The recording hierarchy differs from this demo; record a new take.");
                }
                return new PhysicsPrefabPlayback(instance, animation, bodies);
            }
            catch
            {
                instance.SetActive(false);
                UnityEngine.Object.Destroy(instance);
                throw;
            }
        }

        public void Start()
        {
            _state = _animation[_animation.clip.name];
            _animation.Play(_animation.clip.name);
            _state.speed = 0f;
            Sample(0f);
        }

        public void Sample(float time)
        {
            _state.time = time;
            _animation.Sample();
        }

        public void Stop()
        {
            if (_animation != null) _animation.Stop();
        }

        public void Destroy()
        {
            if (Instance == null) return;
            Instance.SetActive(false);
            UnityEngine.Object.Destroy(Instance);
            Instance = null;
        }
    }
}
