using UnityEngine;

namespace Common.OptimizeTool.Samples
{
    internal static class OptimizeToolPhysicsStatusFormatter
    {
        public static string Format(OptimizeToolPhysicsDemo demo)
        {
            string saved = demo.SavedPrefab == null ? "No recording yet" : "Saved recording ready";
            bool recording = demo.State == OptimizeToolPhysicsDemo.DemoState.Recording;
            bool failed = demo.State == OptimizeToolPhysicsDemo.DemoState.Error;
            string source = recording
                ? $"LEFT   LIVE RECORDING    {demo.SourceBodyCount} Rigidbodies"
                : failed ? "LEFT   RECORDING FAILED  physics held"
                : demo.HasRecordingReference ? "LEFT   RECORDED ORIGINAL  physics held" : "LEFT   REFERENCE MISSING  physics held";
            string comparison = recording ? "Capturing original physics observations...\n"
                : failed ? (demo.SavedPrefab != null
                    ? "Previous saved take available: COMPARE or RECORD again.\n"
                    : "No saved take available: RECORD to retry.\n")
                : demo.HasRecordingReference
                ? $"Peak recorded-pose delta: {demo.MaxPositionError:0.000000} m / {demo.MaxRotationError:0.000} deg\n"
                    + $"Checked {demo.ComparisonSampleCount} / {demo.RecordingReference.ObservationCount} original physics observations.\n"
                : "Recorded-pose delta unavailable: RECORD a new take.\n"
                    + "Legacy Prefab playback remains available.\n";
            AnimationClip clip = demo.SavedPrefab != null ? demo.SavedPrefab.GetComponent<Animation>()?.clip : null;
            float duration = recording || failed || clip == null ? demo.Duration : clip.length;
            return $"{demo.State.ToString().ToUpperInvariant()}   {demo.Elapsed:0.00} / {duration:0.00} s\n"
                + source + "\nRIGHT  RECORDED PREFAB    0 Rigidbodies\n\n"
                + (!string.IsNullOrEmpty(demo.LastError) ? "Recording failed: " + demo.LastError : saved) + "\n"
                + $"RECORD: still for {demo.ReleaseDelay:0.0} s, then real physics.\n"
                + (demo.HasRecordingReference
                    ? "COMPARE: original observations and Prefab at the same time.\n"
                    : "COMPARE: play the saved Prefab without physics.\n")
                + comparison
                + (Application.isEditor
                    ? failed ? "The failed attempt was not saved." : "Saved Prefabs replay without physics calculations."
                    : "Recording requires the Unity Editor.");
        }
    }
}
