#if UNITY_EDITOR
namespace Common.OptimizeTool
{
    internal sealed class PhysicsRecordingSettings
    {
        public float Interval, PositionThreshold, RotationThreshold;
        public bool OnlyIfMoved, Overwrite;
        public string Folder, Name;
        public string ClipPath => $"{Folder}/{Name}.anim";
        public string PrefabPath => $"{Folder}/{Name}.prefab";
        public string ReferencePath => PhysicsRecordingReference.AssetPathForClip(ClipPath);
    }
}
#endif
