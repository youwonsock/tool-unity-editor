#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace Common.OptimizeTool
{
    /// <summary>Undo-aware scene application, independent from geometry construction and asset paths.</summary>
    internal static class MeshSceneOutput
    {
        internal static GameObject Replace(Transform parent, string name, GameObject previous,
            Mesh[] meshes, MeshBuildResult result, bool disableSources)
        {
            if (previous != null) Undo.DestroyObjectImmediate(previous);
            var root = new GameObject(name + " Results");
            Undo.RegisterCreatedObjectUndo(root, "Create combined result");
            root.transform.SetParent(parent, false);
            for (int i = 0; i < meshes.Length; i++)
            {
                var output = new GameObject(meshes[i].name, typeof(MeshFilter), typeof(MeshRenderer));
                Undo.RegisterCreatedObjectUndo(output, "Create combined renderer");
                output.transform.SetParent(root.transform, false);
                output.GetComponent<MeshFilter>().sharedMesh = meshes[i];
                MeshRenderer renderer = output.GetComponent<MeshRenderer>();
                renderer.sharedMaterials = result.Parts[i].Materials;
                result.RendererSettings.ApplyTo(renderer);
            }
            if (disableSources)
                foreach (Renderer renderer in result.SourceRenderers)
                {
                    Undo.RegisterCompleteObjectUndo(renderer, "Disable source renderer");
                    renderer.enabled = false;
                    PrefabUtility.RecordPrefabInstancePropertyModifications(renderer);
                }
            return root;
        }
    }
}
#endif
