#if UNITY_EDITOR
using System;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using Common.OptimizeTool.Samples;

namespace Common.OptimizeTool.Tests
{
    public sealed class PhysicsRecorderCompatibilityTests
    {
        [Test]
        public void ExistingEntryPointsAndSerializedPrefabReferencesRemainAvailable()
        {
            Type recorder = typeof(PhysicsRecorder);
            Assert.NotNull(recorder.GetMethod("Init", Type.EmptyTypes));
            Assert.NotNull(recorder.GetMethod("Release", Type.EmptyTypes));
            Assert.NotNull(recorder.GetMethod("StopRecording", Type.EmptyTypes));
            MethodInfo start = recorder.GetMethod("StartRecording", new[] { typeof(float), typeof(string) });
            Assert.NotNull(start);
            Assert.IsTrue(start.GetParameters()[1].IsOptional);
            Assert.IsNull(start.GetParameters()[1].DefaultValue);
            foreach (string name in new[] { "IsInitialized", "IsFaulted", "IsRecording", "IsSaving", "IsSaveCompleted" })
                Assert.AreEqual(typeof(bool), recorder.GetProperty(name)?.PropertyType, name);
            Assert.AreEqual(typeof(Exception), recorder.GetProperty("LastError")?.PropertyType);
            Assert.AreEqual(typeof(AnimationClip), recorder.GetProperty("ResultClip")?.PropertyType);
            Assert.AreEqual(typeof(GameObject), recorder.GetProperty("ResultPrefab")?.PropertyType);
            foreach (string name in new[] { "Record", "Compare", "ResetDemo", "GetStatusText" })
                Assert.NotNull(typeof(OptimizeToolPhysicsDemo).GetMethod(name, Type.EmptyTypes), name);

            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/_OptimizeTool/Prefab/OptimizeToolShowcase.prefab");
            Assert.NotNull(prefab);
            OptimizeToolPhysicsDemo demo = prefab.GetComponent<OptimizeToolPhysicsDemo>();
            Assert.NotNull(demo);
            PhysicsRecorder component = demo.Recorder;
            Assert.NotNull(component);
            var serialized = new SerializedObject(component);
            foreach (string name in new[] { "_root", "_recordInterval", "_recordOnlyIfMoved", "_positionThreshold",
                "_rotationThreshold", "_savePath", "_animationFileName", "_overwriteExistingAssets" })
                Assert.NotNull(serialized.FindProperty(name), name);
            Assert.NotNull(serialized.FindProperty("_root").objectReferenceValue);
            var presentation = new SerializedObject(demo);
            foreach (string name in new[] { "_demoRoot", "_sourceRoot", "_replayAnchor", "_view", "_recorder" })
                Assert.NotNull(presentation.FindProperty(name).objectReferenceValue, name);
            Assert.IsFalse(prefab.GetComponentsInChildren<MonoBehaviour>(true).Any(c => c == null));
            Assert.AreEqual(component, presentation.FindProperty("_recorder").objectReferenceValue);
        }
    }
}
#endif
